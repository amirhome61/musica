# -*- coding: utf-8 -*-
"""Plugin entry: lists the playlist files and starts the player script for the chosen one."""
import json
import sys
from urllib.parse import parse_qsl, quote, unquote

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import common as C


def list_playlists(handle, base):
    S = C.load_settings()
    folder = S['playlists_dir']
    dirs, files = xbmcvfs.listdir(folder)
    names = sorted(f for f in files if f.lower().endswith('.json'))
    C.log('INFO', 'Listing playlists in %s: %d file(s)' % (folder, len(names)))
    if not names:
        C.report('ERROR', 'No playlist files (*.json) found in %s' % folder)
    for n in names:
        label = n
        plot = ''
        playable = True
        try:
            data = json.loads(C.read_text(C.join(folder, n)))
            label = data.get('name') or n
            plot = '\n'.join('%s (%s)' % (e.get('title', '?'), e.get('concert', '')) for e in data.get('entries', []))
        except Exception as e:
            C.report('ERROR', 'Playlist file %s cannot be read: %s' % (n, e))
            label = '%s  [ERROR: unreadable]' % n
            playable = False
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label, 'plot': plot})
        li.setProperty('IsPlayable', 'true' if playable else 'false')
        url = '%s?action=play&file=%s' % (base, quote(n)) if playable else base
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)


def start_player(handle, name):
    # Nothing is resolved here: the player script runs the playlist on its own.
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    C.log('INFO', 'Starting the player script for %s' % name)
    xbmc.executebuiltin('RunScript(%s,play,%s)' % (C.ADDON_ID, quote(name)))


def main():
    base = sys.argv[0]
    handle = int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    try:
        if params.get('action') == 'play':
            start_player(handle, unquote(params['file']))
        else:
            list_playlists(handle, base)
    except C.ConfigError as e:
        C.report('ERROR', str(e), modal=True)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    except Exception as e:
        C.report('ERROR', 'Unexpected error: %s' % e, exc=True, modal=True)
        xbmcplugin.endOfDirectory(handle, succeeded=False)


main()
