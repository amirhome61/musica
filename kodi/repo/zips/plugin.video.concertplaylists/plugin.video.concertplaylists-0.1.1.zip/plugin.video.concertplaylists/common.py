# -*- coding: utf-8 -*-
"""Shared helpers: settings, path handling, log file and on-screen errors."""
import os
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_ADDON = xbmcaddon.Addon()
ADDON_ID = _ADDON.getAddonInfo('id')
NAME = _ADDON.getAddonInfo('name')
PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
LOG_PATH = os.path.join(PROFILE, 'concertplaylists.log')

RUN_ERRORS = []      # every error and warning of this run, for the final summary
_SETTINGS = None     # set by load_settings(), used for on-screen message time


class ConfigError(Exception):
    pass


class PlaylistError(Exception):
    pass


def log(level, msg):
    line = '%s %-5s %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), level, msg)
    try:
        if not os.path.isdir(PROFILE):
            os.makedirs(PROFILE)
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception as e:  # the log must never stop the add-on
        xbmc.log('[%s] cannot write the log file %s: %s' % (ADDON_ID, LOG_PATH, e), xbmc.LOGERROR)
    kodi_level = xbmc.LOGINFO
    if level == 'ERROR':
        kodi_level = xbmc.LOGERROR
    elif level == 'WARN':
        kodi_level = xbmc.LOGWARNING
    xbmc.log('[%s] %s' % (ADDON_ID, msg), kodi_level)


def trim_log():
    """Keep the log file under the configured size (drops the oldest half)."""
    try:
        limit = int(_SETTINGS['log_max_kb']) * 1024
        if os.path.isfile(LOG_PATH) and os.path.getsize(LOG_PATH) > limit:
            with open(LOG_PATH, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            with open(LOG_PATH, 'w', encoding='utf-8') as f:
                f.writelines(lines[len(lines) // 2:])
    except Exception as e:
        xbmc.log('[%s] cannot trim the log: %s' % (ADDON_ID, e), xbmc.LOGERROR)


def report(level, msg, exc=False, modal=False):
    """Log a problem, remember it for the summary and show it on screen."""
    if exc:
        msg = msg + '\n' + traceback.format_exc()
    log(level, msg)
    RUN_ERRORS.append('%s: %s' % (level, msg.split('\n')[0]))
    short = msg.split('\n')[0]
    try:
        if modal:
            xbmcgui.Dialog().ok(NAME, '%s\n\nLog file: %s' % (short, LOG_PATH))
        elif _SETTINGS is None or _SETTINGS['show_notifications']:
            icon = xbmcgui.NOTIFICATION_ERROR if level == 'ERROR' else xbmcgui.NOTIFICATION_WARNING
            ms = int(_SETTINGS['notify_ms']) if _SETTINGS else 8000
            xbmcgui.Dialog().notification(NAME, short, icon, ms)
    except Exception as e:
        xbmc.log('[%s] cannot show a message: %s' % (ADDON_ID, e), xbmc.LOGERROR)


def load_settings():
    global _SETTINGS
    a = xbmcaddon.Addon()

    def text(key):
        v = a.getSetting(key).strip()
        if not v:
            raise ConfigError('Setting "%s" is empty. Open the add-on settings and fill it in.' % key)
        return v

    def number(key):
        v = a.getSetting(key).strip()
        try:
            f = float(v)
        except ValueError:
            raise ConfigError('Setting "%s" must be a number (it is "%s").' % (key, v))
        if f < 0:
            raise ConfigError('Setting "%s" must not be negative (it is %s).' % (key, v))
        return f

    s = {
        'library_root': text('library_root'),
        'playlists_dir': text('playlists_dir'),
        'poll_s': number('poll_s'),
        'start_timeout_s': number('start_timeout_s'),
        'idle_grace_s': number('idle_grace_s'),
        'stop_confirm_s': number('stop_confirm_s'),
        'seek_settle_s': number('seek_settle_s'),
        'seek_tolerance_s': number('seek_tolerance_s'),
        'start_margin_s': number('start_margin_s'),
        'end_margin_s': number('end_margin_s'),
        'notify_ms': number('notify_ms'),
        'log_max_kb': number('log_max_kb'),
        'show_notifications': a.getSetting('show_notifications') == 'true',
    }
    if s['poll_s'] <= 0:
        raise ConfigError('Setting "poll_s" must be greater than zero.')
    _SETTINGS = s
    trim_log()
    return s


def join(root, rel):
    """Join a library root and a relative path ('/' separated) using the root's own style."""
    sep = '\\' if ('\\' in root and '://' not in root) else '/'
    root = root.rstrip('/\\')
    parts = [p for p in rel.replace('\\', '/').split('/') if p]
    return root + sep + sep.join(parts) if parts else root


def read_text(path):
    f = xbmcvfs.File(path)
    try:
        data = f.read()
    finally:
        f.close()
    if isinstance(data, (bytes, bytearray)):
        data = bytes(data).decode('utf-8', 'replace')
    return data.lstrip('﻿')
