# -*- coding: utf-8 -*-
"""Plays one playlist file: builds a Kodi playlist, seeks every item to its track start
and moves on at its track end. Every problem is logged and shown on screen."""
import json
import re
import sys
import time
from urllib.parse import unquote

import xbmc
import xbmcgui
import xbmcvfs

import common as C

SOURCES = ('mkv', 'bluray', 'dvd')


def _number(e, key, idx, allow_none=False):
    v = e.get(key)
    if v is None and allow_none:
        return None
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise C.PlaylistError('entry %d: "%s" must be a number' % (idx, key))
    return float(v)


def _integer(e, key, idx):
    v = e.get(key)
    if isinstance(v, bool) or not isinstance(v, int):
        raise C.PlaylistError('entry %d: "%s" must be a whole number' % (idx, key))
    return v


def resolve(S, e, idx, cache):
    """Return the Kodi path to play for one playlist entry."""
    src = e.get('source')
    rel = e.get('path')
    if src not in SOURCES:
        raise C.PlaylistError('entry %d: unknown source "%s" (use %s)' % (idx, src, ', '.join(SOURCES)))
    if not isinstance(rel, str) or not rel:
        raise C.PlaylistError('entry %d: "path" is missing' % idx)
    full = C.join(S['library_root'], rel)
    if src == 'mkv':
        if not xbmcvfs.exists(full):
            raise C.PlaylistError('entry %d: file not found: %s' % (idx, full))
        return full
    if src == 'bluray':
        n = _integer(e, 'playlist', idx)
        mpls = C.join(full, 'PLAYLIST/%05d.mpls' % n)
        if not xbmcvfs.exists(mpls):
            raise C.PlaylistError('entry %d: Blu-ray playlist not found: %s' % (idx, mpls))
        return mpls
    vts = _integer(e, 'vts', idx)
    key = (full, vts)
    if key not in cache:
        dirs, files = xbmcvfs.listdir(full)
        pat = re.compile(r'^VTS_%02d_([1-9][0-9]*)\.VOB$' % vts, re.I)
        parts = sorted((int(m.group(1)), f) for f in files for m in [pat.match(f)] if m)
        if not parts:
            raise C.PlaylistError('entry %d: no VTS_%02d_*.VOB files in %s (folder missing or wrong title set)' % (idx, vts, full))
        paths = [C.join(full, f) for _, f in parts]
        if any(',' in p for p in paths):
            raise C.PlaylistError('entry %d: a VOB path contains a comma, which stacks cannot handle: %s' % (idx, full))
        cache[key] = 'stack://' + ' , '.join(paths)
    return cache[key]


def build(S, name):
    path = C.join(S['playlists_dir'], name)
    if not xbmcvfs.exists(path):
        raise C.PlaylistError('Playlist file not found: %s' % path)
    try:
        data = json.loads(C.read_text(path))
    except ValueError as e:
        raise C.PlaylistError('Playlist file %s is not valid JSON: %s' % (name, e))
    raw = data.get('entries') if isinstance(data, dict) else None
    if not isinstance(raw, list) or not raw:
        raise C.PlaylistError('Playlist file %s has no "entries" list' % name)
    entries, urls, cache = [], [], {}
    for i, e in enumerate(raw, 1):
        try:
            if not isinstance(e, dict):
                raise C.PlaylistError('entry %d is not an object' % i)
            title = e.get('title')
            if not isinstance(title, str) or not title:
                raise C.PlaylistError('entry %d: "title" is missing' % i)
            start = _number(e, 'start', i)
            end = _number(e, 'end', i, allow_none=True)
            if start < 0 or (end is not None and end <= start):
                raise C.PlaylistError('entry %d: start %s and end %s are not a valid range' % (i, start, end))
            url = resolve(S, e, i, cache)
            entries.append({'title': title, 'concert': e.get('concert', ''), 'start': start, 'end': end, 'n': i})
            urls.append(url)
        except C.PlaylistError as err:
            C.report('ERROR', 'Playlist %s, skipped: %s' % (name, err))
    if not entries:
        raise C.PlaylistError('Playlist %s has no playable entries' % name)
    return entries, urls


class Runner(xbmc.Player):
    def __init__(self):
        xbmc.Player.__init__(self)
        self.av_seq = 0
        self.error_seq = 0
        self.stopped = False
        self.ended = False
        self.expected_stop = False
        self.stop_seen = None

    def onAVStarted(self):
        self.av_seq += 1
        C.log('INFO', 'Kodi event: AV started')

    def onPlayBackStopped(self):
        self.stopped = True
        C.log('INFO', 'Kodi event: playback stopped (expected=%s, playing=%s)' % (
            self.expected_stop, self.isPlayingVideo()))

    def onPlayBackEnded(self):
        self.ended = True
        C.log('INFO', 'Kodi event: playback ended (playing=%s)' % self.isPlayingVideo())

    def onPlayBackError(self):
        self.error_seq += 1
        C.log('WARN', 'Kodi event: playback error')


def safe_time(player):
    try:
        return player.getTime()
    except RuntimeError:
        return None


def user_stopped(S, player):
    """True when the user stopped playback. A stop event is only confirmed when nothing plays for
    stop_confirm_s seconds: Kodi also reports stops while it moves between the parts of a DVD stack."""
    if player.stopped and not player.expected_stop:
        if player.isPlayingVideo():
            player.stopped = False
            player.stop_seen = None
            return False
        if player.stop_seen is None:
            player.stop_seen = time.time()
        return time.time() - player.stop_seen >= S['stop_confirm_s']
    return False


def stop_and_wait(S, player, mon):
    """Stop the current item and wait until Kodi confirms it (so no stale event reaches the next item)."""
    player.expected_stop = True
    if player.isPlaying():
        player.stop()
    t0 = time.time()
    while not (player.stopped or player.ended) and time.time() - t0 < S['idle_grace_s']:
        if mon.waitForAbort(S['poll_s']):
            return
    if not (player.stopped or player.ended):
        C.report('WARN', 'Kodi did not confirm the stop within %.0f s' % S['idle_grace_s'])


def play_one(S, player, mon, e, url, total):
    """Play one track. Returns 'next', 'stop' (user stopped everything) or 'abort' (Kodi is closing)."""
    player.stopped = player.ended = player.expected_stop = False
    player.stop_seen = None
    seq0, err0 = player.av_seq, player.error_seq
    li = xbmcgui.ListItem(label=e['title'], path=url)
    li.setInfo('video', {'title': e['title'], 'album': e['concert']})
    t0 = time.time()
    C.log('INFO', 'Item %d of %d: "%s" (%s), requesting playback' % (e['n'], total, e['title'], e['concert']))
    player.play(url, li)
    while player.av_seq == seq0:
        if mon.waitForAbort(S['poll_s']):
            return 'abort'
        if user_stopped(S, player):
            C.log('INFO', 'Stopped by the user before item %d started' % e['n'])
            return 'stop'
        if player.error_seq != err0:
            C.report('ERROR', 'Kodi could not play item %d "%s"' % (e['n'], e['title']))
            return 'next'
        if time.time() - t0 > S['start_timeout_s']:
            C.report('ERROR', 'Item %d "%s" did not start within %.0f s, skipping it' % (
                e['n'], e['title'], S['start_timeout_s']))
            stop_and_wait(S, player, mon)
            return 'next'
    started = time.time()
    target = max(0.0, e['start'] - S['start_margin_s'])
    if target > 0:
        player.seekTime(target)
        C.log('INFO', 'Item %d playing (started in %.1f s), seeking to %.2f s' % (e['n'], started - t0, target))
        seek_t0 = time.time()
        while True:
            if mon.waitForAbort(S['poll_s']):
                return 'abort'
            if user_stopped(S, player):
                C.log('INFO', 'Stopped by the user during the seek of item %d' % e['n'])
                return 'stop'
            t = safe_time(player)
            if t is not None and abs(t - target) <= S['seek_tolerance_s']:
                C.log('INFO', 'Item %d seek done: at %.2f s, wanted %.2f s (%.1f s after the request)' % (
                    e['n'], t, target, time.time() - seek_t0))
                break
            if time.time() - seek_t0 > S['seek_settle_s']:
                C.report('WARN', 'Item %d "%s": seek landed at %s instead of %.1f s' % (
                    e['n'], e['title'], 'an unknown time' if t is None else '%.1f s' % t, target))
                break
    else:
        C.log('INFO', 'Item %d playing from the beginning (started in %.1f s)' % (e['n'], started - t0))
    last_playing = time.time()
    while True:
        if mon.waitForAbort(S['poll_s']):
            return 'abort'
        if user_stopped(S, player):
            C.log('INFO', 'Stopped by the user during item %d' % e['n'])
            return 'stop'
        if player.ended and not player.isPlayingVideo():
            C.log('INFO', 'Item %d reached the natural end of its source' % e['n'])
            return 'next'
        if not player.isPlayingVideo():
            if time.time() - last_playing > S['idle_grace_s']:
                C.report('ERROR', 'Item %d "%s": playback stopped unexpectedly' % (e['n'], e['title']))
                return 'stop'
            continue
        last_playing = time.time()
        if e['end'] is not None:
            t = safe_time(player)
            if t is not None and t >= e['end'] - S['end_margin_s']:
                C.log('INFO', 'Item %d reached its end at %.2f s (end %.2f s)' % (e['n'], t, e['end']))
                stop_and_wait(S, player, mon)
                return 'next'


def play(S, name):
    entries, urls = build(S, name)
    total = len(entries)
    C.log('INFO', 'Playlist %s: %d playable item(s)' % (name, total))
    for e, u in zip(entries, urls):
        C.log('INFO', '  item %d: "%s" [%s] %.2f..%s  %s' % (
            e['n'], e['title'], e['concert'], e['start'],
            'end' if e['end'] is None else '%.2f' % e['end'], u))
    player = Runner()
    mon = xbmc.Monitor()
    result = 'next'
    for e, u in zip(entries, urls):
        result = play_one(S, player, mon, e, u, total)
        if result != 'next':
            break
    if result == 'abort' and player.isPlaying():
        player.stop()
    C.log('INFO', 'Playlist %s done (%s), %d problem(s) reported' % (name, result, len(C.RUN_ERRORS)))
    if C.RUN_ERRORS and not mon.abortRequested():
        xbmcgui.Dialog().textviewer(C.NAME, 'Problems while playing %s:\n\n%s\n\nLog file: %s' % (
            name, '\n'.join(C.RUN_ERRORS), C.LOG_PATH))


def main():
    try:
        S = C.load_settings()
        args = sys.argv[1:]
        if len(args) != 2 or args[0] != 'play':
            raise C.ConfigError('Unexpected start arguments: %s' % args)
        C.log('INFO', '--- start: %s' % args)
        C.log('INFO', 'Settings in use: %s' % ', '.join('%s=%s' % (k, S[k]) for k in sorted(S)))
        play(S, unquote(args[1]))
    except (C.ConfigError, C.PlaylistError) as e:
        C.report('ERROR', str(e), modal=True)
    except Exception as e:
        C.report('ERROR', 'Unexpected error: %s' % e, exc=True, modal=True)


main()
