# -*- coding: utf-8 -*-
"""Plugin entry: lists the playlist files and starts the player script for the chosen one."""
import json
import sys
from urllib.parse import parse_qsl, quote, unquote

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

import common as C


def list_playlists(handle, base):
    S = C.load_settings()
    folder = S['playlists_dir']
    probe = folder if folder.endswith(('/', '\\')) else folder + ('/' if '/' in folder else '\\')
    if not xbmcvfs.exists(probe):
        C.report('ERROR', 'Playlist folder not found or not reachable: %s' % folder, modal=True)
        return
    dirs, files = xbmcvfs.listdir(probe)
    C.log('INFO', 'Folder %s: %d subfolder(s), %d file(s): %s' % (probe, len(dirs), len(files), ', '.join(sorted(files)[:20])))
    names = sorted(f for f in files if f.lower().endswith('.json'))
    C.log('INFO', 'Listing playlists in %s: %d file(s)' % (folder, len(names)))
    if not names:
        C.report('ERROR', 'No playlist files (*.json) in %s (it holds %d file(s), %d subfolder(s))' % (folder, len(files), len(dirs)))
    for n in names:
        label = n
        plot = ''
        playable = True
        try:
            data = json.loads(C.read_text(C.join(folder, n)))
            label = data.get('name') or n
            plot = '\n'.join('%s (%s)' % (e.get('title', '?'), e.get('concert', '')) for e in data.get('entries', []))
        except Exception as e:
            C.report('ERROR', 'Playlist file %s cannot be read: %s' % (n, e))
            label = '%s  [ERROR: unreadable]' % n
            playable = False
        li = xbmcgui.ListItem(label=label)
        li.setInfo('video', {'title': label, 'plot': plot})
        url = '%s?action=open&file=%s' % (base, quote(n)) if playable else base
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=playable)
    xbmcplugin.endOfDirectory(handle)


def _fmt(sec):
    sec = int(round(sec))
    return '%d:%02d:%02d' % (sec // 3600, sec % 3600 // 60, sec % 60) if sec >= 3600 else '%d:%02d' % (sec // 60, sec % 60)


def read_entries(name):
    S = C.load_settings()
    try:
        data = json.loads(C.read_text(C.join(S['playlists_dir'], name)))
        raw = data['entries']
    except Exception as e:
        raise C.PlaylistError('Playlist file %s cannot be read: %s' % (name, e))
    out = []
    for i, e in enumerate(raw, 1):
        label = '%s - %s' % (e.get('concert', '?'), e.get('title', '?'))
        try:
            if e.get('end') is not None:
                label += '  [%s]' % _fmt(float(e['end']) - float(e['start']))
        except (TypeError, ValueError):
            pass
        out.append((i, label))
    return out


def open_playlist(handle, base, name):
    entries = read_entries(name)
    q = quote(name)
    for label, action, extra in (('Play all', 'play', ''), ('Choose tracks to play...', 'choose', '')):
        li = xbmcgui.ListItem(label=label)
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle, '%s?action=%s&file=%s' % (base, action, q), li, isFolder=False)
    for i, label in entries:
        li = xbmcgui.ListItem(label='%d. %s' % (i, label))
        li.setInfo('video', {'title': label})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle, '%s?action=play&file=%s&tracks=%d' % (base, q, i), li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)


def choose_tracks(handle, name):
    entries = read_entries(name)
    picked = xbmcgui.Dialog().multiselect('Choose tracks to play', [l for _i, l in entries],
                                          preselect=list(range(len(entries))))
    if not picked:
        C.log('INFO', 'Track selection cancelled or empty')
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    start_player(handle, name, ';'.join(str(entries[k][0]) for k in picked))


def start_player(handle, name, tracks=''):
    # Nothing is resolved here: the player script runs the playlist on its own.
    xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
    C.log('INFO', 'Starting the player script for %s (tracks: %s)' % (name, tracks or 'all'))
    xbmc.executebuiltin('RunScript(%s,play,%s,%s)' % (C.ADDON_ID, quote(name), tracks))


def main():
    base = sys.argv[0]
    handle = int(sys.argv[1])
    params = dict(parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    try:
        if params.get('action') == 'play':
            start_player(handle, unquote(params['file']), params.get('tracks', ''))
        elif params.get('action') == 'choose':
            choose_tracks(handle, unquote(params['file']))
        elif params.get('action') == 'open':
            open_playlist(handle, base, unquote(params['file']))
        else:
            list_playlists(handle, base)
    except (C.ConfigError, C.PlaylistError) as e:
        C.report('ERROR', str(e), modal=True)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    except Exception as e:
        C.report('ERROR', 'Unexpected error: %s' % e, exc=True, modal=True)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
    finally:
        C.publish_log()


main()
