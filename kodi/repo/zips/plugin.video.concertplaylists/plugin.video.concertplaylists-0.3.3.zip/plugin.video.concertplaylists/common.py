# -*- coding: utf-8 -*-
"""Shared helpers: settings, path handling, log file and on-screen errors."""
import os
import time
import traceback

import json
import re
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_ADDON = xbmcaddon.Addon()
ADDON_ID = _ADDON.getAddonInfo('id')
NAME = _ADDON.getAddonInfo('name')
PROFILE = xbmcvfs.translatePath(_ADDON.getAddonInfo('profile'))
LOG_PATH = os.path.join(PROFILE, 'concertplaylists.log')

RUN_ERRORS = []      # every error and warning of this run, for the final summary
VERSION = xbmcaddon.Addon().getAddonInfo('version')


def mask(u):
    """Hide a user name and password inside a path."""
    return re.sub(r'(://)[^@/]*@', r'\1***@', u)


_SETTINGS = None     # set by load_settings(), used for on-screen message time


class ConfigError(Exception):
    pass


class PlaylistError(Exception):
    pass


def log(level, msg):
    line = '%s %-5s %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), level, msg)
    try:
        if not os.path.isdir(PROFILE):
            os.makedirs(PROFILE)
        with open(LOG_PATH, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception as e:  # the log must never stop the add-on
        xbmc.log('[%s] cannot write the log file %s: %s' % (ADDON_ID, LOG_PATH, e), xbmc.LOGERROR)
    kodi_level = xbmc.LOGINFO
    if level == 'ERROR':
        kodi_level = xbmc.LOGERROR
    elif level == 'WARN':
        kodi_level = xbmc.LOGWARNING
    xbmc.log('[%s] %s' % (ADDON_ID, msg), kodi_level)
    if _LOG_DIR and _SETTINGS and time.time() - _LAST_PUB >= _SETTINGS['log_publish_s']:
        publish_log()


def trim_log():
    """Keep the log file under the configured size (drops the oldest half)."""
    try:
        limit = int(_SETTINGS['log_max_kb']) * 1024
        if os.path.isfile(LOG_PATH) and os.path.getsize(LOG_PATH) > limit:
            with open(LOG_PATH, 'r', encoding='utf-8', errors='replace') as f:
                lines = f.readlines()
            with open(LOG_PATH, 'w', encoding='utf-8') as f:
                f.writelines(lines[len(lines) // 2:])
    except Exception as e:
        xbmc.log('[%s] cannot trim the log: %s' % (ADDON_ID, e), xbmc.LOGERROR)


_LOG_DIR = None
_LAST_PUB = 0.0


def publish_log():
    """Copy the log next to the playlists so it can be read from the NAS."""
    global _LAST_PUB
    if not _LOG_DIR:
        return
    _LAST_PUB = time.time()
    try:
        if not xbmcvfs.copy(LOG_PATH, join(_LOG_DIR, 'concertplaylists.log')):
            xbmc.log('[%s] could not copy the log to %s' % (ADDON_ID, _LOG_DIR), xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log('[%s] could not copy the log: %s' % (ADDON_ID, e), xbmc.LOGWARNING)


def report(level, msg, exc=False, modal=False):
    """Log a problem, remember it for the summary and show it on screen."""
    if exc:
        msg = msg + '\n' + traceback.format_exc()
    log(level, msg)
    publish_log()
    RUN_ERRORS.append('%s: %s' % (level, msg.split('\n')[0]))
    short = msg.split('\n')[0]
    try:
        if modal:
            xbmcgui.Dialog().ok(NAME, '%s\n\nLog file: %s' % (short, LOG_PATH))
        elif _SETTINGS is None or _SETTINGS['show_notifications']:
            icon = xbmcgui.NOTIFICATION_ERROR if level == 'ERROR' else xbmcgui.NOTIFICATION_WARNING
            ms = int(_SETTINGS['notify_ms']) if _SETTINGS else 8000
            xbmcgui.Dialog().notification(NAME, short, icon, ms)
    except Exception as e:
        xbmc.log('[%s] cannot show a message: %s' % (ADDON_ID, e), xbmc.LOGERROR)


def load_settings():
    global _SETTINGS
    a = xbmcaddon.Addon()

    def text(key):
        v = a.getSetting(key).strip()
        if not v:
            raise ConfigError('Setting "%s" is empty. Open the add-on settings and fill it in.' % key)
        return v

    def number(key):
        v = a.getSetting(key).strip()
        try:
            f = float(v)
        except ValueError:
            raise ConfigError('Setting "%s" must be a number (it is "%s").' % (key, v))
        if f < 0:
            raise ConfigError('Setting "%s" must not be negative (it is %s).' % (key, v))
        return f

    s = {
        'library_root': a.getSetting('library_root').strip(),
        'playlists_dir': a.getSetting('playlists_dir').strip(),
        'playlists_subfolder': text('playlists_subfolder'),
        'poll_s': number('poll_s'),
        'start_timeout_s': number('start_timeout_s'),
        'idle_grace_s': number('idle_grace_s'),
        'stop_confirm_s': number('stop_confirm_s'),
        'seek_settle_s': number('seek_settle_s'),
        'seek_tolerance_s': number('seek_tolerance_s'),
        'start_margin_s': number('start_margin_s'),
        'end_margin_s': number('end_margin_s'),
        'notify_ms': number('notify_ms'),
        'log_max_kb': number('log_max_kb'),
        'log_publish_s': number('log_publish_s'),
        'progress_log_s': number('progress_log_s'),
        'kodi_call_timeout_s': number('kodi_call_timeout_s'),
        'show_notifications': a.getSetting('show_notifications') == 'true',
    }
    if s['poll_s'] <= 0:
        raise ConfigError('Setting "poll_s" must be greater than zero.')
    trim_log()
    global _LOG_DIR
    if s['playlists_dir'] and _dir_exists(s['playlists_dir']):
        _LOG_DIR = s['playlists_dir']
    try:
        _resolve_paths(s)
    finally:
        publish_log()
    _LOG_DIR = s['playlists_dir']
    _SETTINGS = s
    return s


def _dir_exists(path):
    p = path if path.endswith(('/', '\\')) else path + ('/' if '/' in path else '\\')
    return xbmcvfs.exists(p)


def _resolve_paths(s):
    """Use the configured folders when they exist; otherwise find them among Kodi's video sources."""
    root, pl, sub = s['library_root'], s['playlists_dir'], s['playlists_subfolder']
    root_ok = bool(root) and _dir_exists(root)
    pl_ok = bool(pl) and _dir_exists(pl)
    if not root and pl_ok:
        tail = sub.replace('\\', '/').strip('/')
        flat = pl.replace('\\', '/').rstrip('/')
        if flat.endswith(tail):
            s['library_root'] = pl[:len(flat) - len(tail)].rstrip('/\\')
            log('INFO', 'Library root taken from the playlists folder: %s' % s['library_root'])
            return
    if root_ok and pl_ok:
        return
    if root and not root_ok:
        log('WARN', 'Configured library_root is not reachable (%s); searching Kodi video sources' % mask(root))
    if pl and not pl_ok:
        log('WARN', 'Configured playlists_dir is not reachable (%s); searching Kodi video sources' % mask(pl))
    found = None
    try:
        res = json.loads(xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': 'Files.GetSources', 'params': {'media': 'video'}})))
        sources = [x['file'] for x in res.get('result', {}).get('sources', [])]
    except Exception as e:
        raise ConfigError('Cannot read the Kodi video sources: %s' % e)
    log('INFO', 'Searching %d Kodi video source(s) for a folder holding "%s"' % (len(sources), sub))
    from urllib.parse import unquote

    def mask(u):
        return re.sub(r'(://)[^@/]*@', r'\1***@', u)

    def expand(src):
        if src.startswith('multipath://'):
            return [unquote(x) for x in src[len('multipath://'):].split('/') if x]
        return [src]

    def ancestors(u):
        # u, then each parent folder, down to smb://host/share (or the scheme root)
        m = re.match(r'^([a-z]+://(?:[^/@]*@)?[^/]+/[^/]+)(/.*)?$', u.rstrip('/'), re.I)
        out = [u.rstrip('/')]
        if m and m.group(2):
            base, rest = m.group(1), m.group(2).strip('/').split('/')
            for n in range(len(rest) - 1, -1, -1):
                out.append(base + ('/' + '/'.join(rest[:n]) if n else ''))
        return out

    tried = set()
    for raw_src in sources:
        for src in expand(raw_src):
            cands = ancestors(src)
            try:
                dirs, _f = xbmcvfs.listdir(src if src.endswith('/') else src + '/')
                cands += [join(src, d) for d in dirs]
            except Exception as e:
                log('WARN', 'Cannot list video source %s: %s' % (mask(src), e))
            log('INFO', 'Video source %s: checking %d folder(s)' % (mask(src), len(cands)))
            for c in cands:
                if c in tried:
                    continue
                tried.add(c)
                if _dir_exists(join(c, sub)):
                    found = c
                    break
            if found:
                break
        if found:
            break
    if not found:
        raise ConfigError('Cannot find the playlist folder "%s" in the library root, the playlists folder '
                          'or any Kodi video source. Set library_root and playlists_dir in the add-on '
                          'settings.' % sub)
    if not root_ok:
        s['library_root'] = found
    if not pl_ok:
        s['playlists_dir'] = join(found, sub)
    log('INFO', 'Found library root %s and playlists folder %s' % (mask(s['library_root']), mask(s['playlists_dir'])))


def join(root, rel):
    """Join a library root and a relative path ('/' separated) using the root's own style."""
    sep = '\\' if ('\\' in root and '://' not in root) else '/'
    root = root.rstrip('/\\')
    parts = [p for p in rel.replace('\\', '/').split('/') if p]
    return root + sep + sep.join(parts) if parts else root


def read_text(path):
    f = xbmcvfs.File(path)
    try:
        data = f.read()
    finally:
        f.close()
    if isinstance(data, (bytes, bytearray)):
        data = bytes(data).decode('utf-8', 'replace')
    return data.lstrip('﻿')
