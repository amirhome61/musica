"""Track list lookup on MusicBrainz. Returns candidate track lists (one per disc of each release)."""
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request


def _get(S, path, params):
    url = S['lookup_url'].rstrip('/') + '/' + path + '?' + urllib.parse.urlencode(dict(params, fmt='json'))
    req = urllib.request.Request(url, headers={'User-Agent': S['lookup_user_agent'], 'Accept': 'application/json'})
    for attempt in range(int(S['lookup_retries']) + 1):
        try:
            with urllib.request.urlopen(req, timeout=float(S['lookup_timeout_s'])) as r:
                data = json.load(r)
            time.sleep(float(S['lookup_delay_s']))
            return data
        except urllib.error.HTTPError as e:
            if e.code not in (429, 502, 503, 504) or attempt >= int(S['lookup_retries']):
                raise
            time.sleep(float(S['lookup_retry_wait_s']) * (attempt + 1))


def _queries(title, artist):
    t = re.sub(r'\s*[\(\[].*?[\)\]]', '', title).strip()
    parts = [p.strip() for p in t.split(' - ') if p.strip()]
    names = []
    if len(parts) > 1:
        names.append(parts[-1])
        names.append(' '.join(parts[1:]))
    names.append(t)
    out = []
    for n in names:
        for a in (artist, ''):
            if (n, a) not in out:
                out.append((n, a))
    return out


def find(S, title, artist, count):
    """Candidates sorted so that those with the same track count as the concert come first."""
    seen, cands = set(), []
    for name, art in _queries(title, artist):
        qs = 'release:"%s"' % name.replace('"', '')
        if art:
            qs += ' AND artist:"%s"' % art.replace('"', '')
        res = _get(S, 'release', {'query': qs, 'limit': int(S['lookup_candidates'])})
        for rel in res.get('releases', []):
            if rel['id'] in seen:
                continue
            seen.add(rel['id'])
            full = _get(S, 'release/' + rel['id'], {'inc': 'recordings'})
            media = full.get('media', [])
            for i, m in enumerate(media, 1):
                names = [t.get('title', '') for t in m.get('tracks', [])]
                if not names:
                    continue
                label = '%s%s' % (rel.get('title', ''), ' (disc %d of %d)' % (i, len(media)) if len(media) > 1 else '')
                cands.append({'release': rel['id'], 'label': label, 'date': rel.get('date', ''), 'format': m.get('format') or '',
                              'score': rel.get('score', 0), 'names': names, 'match': len(names) == count})
        if any(c['match'] for c in cands):
            break
    cands.sort(key=lambda c: (not c['match'], -int(c['score'] or 0)))
    return cands
