"""Concert scanner: finds concerts under the library root and reads tracks and audio streams.

Read-only on the library. No values are hard-coded here: everything comes from the settings dict.
"""
import json
import os
import re
import struct
import subprocess

VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.ts', '.m2ts')
SECTOR = 2048


def _run_ffprobe(ffprobe, path, args):
    cmd = [ffprobe, '-v', 'error', '-of', 'json'] + args + [path]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    if r.returncode != 0:
        raise RuntimeError('ffprobe failed for %s: %s' % (path, r.stderr.strip()[:300]))
    return json.loads(r.stdout or '{}')


def _audio_from_ffprobe(data):
    out = []
    for s in data.get('streams', []):
        if s.get('codec_type') != 'audio':
            continue
        tags = s.get('tags') or {}
        prof = s.get('profile') or ''
        out.append({
            'position': len(out),
            'codec': s.get('codec_name', ''),
            'profile': prof,
            'channels': int(s.get('channels') or 0),
            'language': (tags.get('language') or tags.get('LANGUAGE') or '').lower(),
            'title': tags.get('title') or tags.get('TITLE') or '',
            'default': bool((s.get('disposition') or {}).get('default')),
        })
    return out


def find_poster(folder, names):
    try:
        files = {f.lower(): f for f in os.listdir(folder)}
    except OSError:
        return None
    for n in names:
        if n.startswith('*'):
            suf = n[1:].lower()
            for low, f in sorted(files.items()):
                if low.endswith(suf):
                    return f
        elif n.lower() in files:
            return files[n.lower()]
    return None


def discover(root, log):
    """Yield (folder, kind, path) for every concert below root. kind: mkv, dvd, bluray."""
    stack = [root]
    while stack:
        folder = stack.pop()
        try:
            entries = sorted(os.scandir(folder), key=lambda e: e.name.lower())
        except OSError as e:
            log('ERROR', 'Cannot list %s: %s' % (folder, e))
            continue
        names = {e.name.upper(): e for e in entries}
        if 'VIDEO_TS' in names and names['VIDEO_TS'].is_dir():
            yield folder, 'dvd', names['VIDEO_TS'].path
            continue
        if 'BDMV' in names and names['BDMV'].is_dir():
            yield folder, 'bluray', names['BDMV'].path
            continue
        vids = [e for e in entries if e.is_file() and e.name.lower().endswith(VIDEO_EXT)]
        for v in vids:
            yield folder, 'mkv', v.path
        for e in entries:
            if e.is_dir() and not e.name.startswith(('_', '.')) and e.name.lower() not in ('extrafanart', 'extrathumbs', 'extras', 'sample'):
                stack.append(e.path)


def scan_mkv(path, ffprobe):
    d = _run_ffprobe(ffprobe, path, ['-show_chapters', '-show_streams', '-show_format'])
    length = float((d.get('format') or {}).get('duration') or 0)
    tracks = []
    for i, c in enumerate(d.get('chapters', []), 1):
        t = (c.get('tags') or {}).get('title') or 'Chapter %d' % i
        tracks.append({'n': i, 'title': t, 'start': round(float(c['start_time']), 3), 'end': round(float(c['end_time']), 3)})
    if not tracks:
        tracks = [{'n': 1, 'title': 'Whole concert', 'start': 0.0, 'end': None}]
    video = next((s for s in d.get('streams', []) if s.get('codec_type') == 'video'), {})
    return {'length': length, 'tracks': tracks, 'audio': _audio_from_ffprobe(d),
            'video': '%sx%s %s' % (video.get('width', '?'), video.get('height', '?'), video.get('codec_name', ''))}


# ---- Blu-ray ----------------------------------------------------------------

def parse_mpls(path):
    d = open(path, 'rb').read()
    pl_start, mark_start = struct.unpack('>II', d[8:16])
    n_items = struct.unpack('>H', d[pl_start + 6:pl_start + 8])[0]
    p = pl_start + 10
    items, acc = [], 0.0
    for _ in range(n_items):
        ln = struct.unpack('>H', d[p:p + 2])[0]
        clip = d[p + 2:p + 7].decode('ascii', 'replace')
        tin, tout = struct.unpack('>II', d[p + 14:p + 22])
        items.append((clip, tin, tout, acc))
        acc += (tout - tin) / 45000.0
        p += 2 + ln
    nm = struct.unpack('>H', d[mark_start + 4:mark_start + 6])[0]
    marks = []
    for k in range(nm):
        q = mark_start + 6 + 14 * k
        if d[q + 1] == 1:
            ref = struct.unpack('>H', d[q + 2:q + 4])[0]
            ts = struct.unpack('>I', d[q + 4:q + 8])[0]
            if ref < len(items):
                _, tin, _, a = items[ref]
                marks.append(a + (ts - tin) / 45000.0)
    return items, marks, acc


def scan_bluray(bdmv, ffprobe):
    pdir = os.path.join(bdmv, 'PLAYLIST')
    best = None
    for f in sorted(os.listdir(pdir)):
        if not f.lower().endswith('.mpls'):
            continue
        items, marks, total = parse_mpls(os.path.join(pdir, f))
        if best is None or total > best[3]:
            best = (f, items, marks, total)
    if best is None:
        raise RuntimeError('no .mpls playlists in %s' % pdir)
    f, items, marks, total = best
    marks = sorted(m for m in marks if m < total - 1.0)
    if not marks or marks[0] > 1.0:
        marks.insert(0, 0.0)
    tracks = []
    for i, st in enumerate(marks):
        en = marks[i + 1] if i + 1 < len(marks) else round(total, 3)
        tracks.append({'n': i + 1, 'title': 'Chapter %d' % (i + 1), 'start': round(st, 3), 'end': round(en, 3)})
    clip = os.path.join(bdmv, 'STREAM', items[0][0] + '.m2ts')
    d = _run_ffprobe(ffprobe, clip, ['-show_streams'])
    video = next((s for s in d.get('streams', []) if s.get('codec_type') == 'video'), {})
    return {'length': total, 'tracks': tracks, 'audio': _audio_from_ffprobe(d),
            'playlist': int(os.path.splitext(f)[0]),
            'clips': [{'name': c, 'offset': round(a, 3), 'dur': round((o - i) / 45000.0, 3)} for c, i, o, a in items], 'video': '%sx%s %s' % (video.get('width', '?'), video.get('height', '?'), video.get('codec_name', ''))}


# ---- DVD ----------------------------------------------------------------------

DVD_AUDIO_CODING = {0: 'ac3', 2: 'mp1', 3: 'mp2', 4: 'pcm', 6: 'dts'}


def _bcd_time(b):
    def f(x):
        return (x >> 4) * 10 + (x & 15)
    fr = b[3]
    rate = 25.0 if (fr >> 6) == 1 else 29.97
    return f(b[0]) * 3600 + f(b[1]) * 60 + f(b[2]) + f(fr & 0x3F) / rate


def _title_sets(video_ts):
    sets = {}
    for f in os.listdir(video_ts):
        m = re.match(r'VTS_(\d\d)_(\d)\.VOB$', f.upper())
        if m and m.group(2) != '0':
            vts = int(m.group(1))
            sets.setdefault(vts, []).append((int(m.group(2)), os.path.join(video_ts, f)))
    for k in sets:
        sets[k].sort()
    return sets


def _pts_at(vobs, sector, sizes):
    """Video PTS (seconds) at or after the given sector of the concatenated VOB files."""
    off = sector * SECTOR
    for (n, path), size in zip(vobs, sizes):
        if off < size:
            break
        off -= size
    else:
        raise RuntimeError('sector %d beyond the title set' % sector)
    with open(path, 'rb') as fh:
        fh.seek(off)
        buf = fh.read(SECTOR * 400)
    pos = 0
    while True:
        pos = buf.find(b'\x00\x00\x01\xe0', pos)
        if pos < 0 or pos + 14 > len(buf):
            raise RuntimeError('no video PTS found near sector %d in %s' % (sector, path))
        if buf[pos + 7] & 0x80:
            b = buf[pos + 9:pos + 14]
            pts = ((b[0] >> 1) & 7) << 30 | b[1] << 22 | (b[2] >> 1) << 15 | b[3] << 7 | b[4] >> 1
            return pts / 90000.0
        pos += 4


def _vts_audio(ifo, vobs, ffprobe):
    naud = struct.unpack('>H', ifo[0x202:0x204])[0]
    audio = []
    for i in range(min(naud, 8)):
        a = ifo[0x204 + 8 * i:0x204 + 8 * i + 8]
        coding = a[0] >> 5
        lang = a[2:4].decode('ascii', 'replace').strip('\x00 ').lower() if (a[0] >> 2) & 3 == 1 else ''
        audio.append({'position': i, 'codec': DVD_AUDIO_CODING.get(coding, 'unknown'), 'profile': '',
                      'channels': (a[1] & 7) + 1, 'language': lang, 'title': '', 'default': i == 0})
    # The IFO may list more audio entries than the VOBs carry (padding); keep as many as ffprobe finds in the VOBs.
    try:
        real = _audio_from_ffprobe(_run_ffprobe(ffprobe, vobs[0][1], ['-show_streams']))
    except RuntimeError:
        real = []
    if real:
        for i, r in enumerate(real):
            if i < len(audio):
                r['language'] = r['language'] or audio[i]['language']
                r['channels'] = r['channels'] or audio[i]['channels']
        audio = real
    return audio


def _vts_titles(ifo):
    """Titles of a title set: for each, the list of chapters as (pgc number, program number)."""
    p = struct.unpack('>I', ifo[0xC8:0xCC])[0] * SECTOR
    nt = struct.unpack('>H', ifo[p:p + 2])[0]
    end = struct.unpack('>I', ifo[p + 4:p + 8])[0]
    offs = [struct.unpack('>I', ifo[p + 8 + 4 * i:p + 12 + 4 * i])[0] for i in range(nt)] + [end + 1]
    return [[struct.unpack('>HH', ifo[p + o:p + o + 4]) for o in range(offs[i], offs[i + 1], 4)] for i in range(nt)]


def _vts_pgcs(ifo):
    pgcit = struct.unpack('>I', ifo[0xCC:0xD0])[0] * SECTOR
    npgc = struct.unpack('>H', ifo[pgcit:pgcit + 2])[0]
    out = []
    for k in range(npgc):
        e = pgcit + 8 + 8 * k
        off = pgcit + struct.unpack('>I', ifo[e + 4:e + 8])[0]
        nprog, ncell = ifo[off + 2], ifo[off + 3]
        pmap = struct.unpack('>H', ifo[off + 0xE6:off + 0xE8])[0]
        cpb = struct.unpack('>H', ifo[off + 0xE8:off + 0xEA])[0]
        cells = []
        for c in range(ncell):
            q = off + cpb + 24 * c
            cells.append({'dur': _bcd_time(ifo[q + 4:q + 8]), 'first': struct.unpack('>I', ifo[q + 8:q + 12])[0],
                          'last': struct.unpack('>I', ifo[q + 20:q + 24])[0]})
        out.append({'dur': _bcd_time(ifo[off + 4:off + 8]), 'prog': [ifo[off + pmap + i] for i in range(nprog)], 'cells': cells})
    return out


def _timeline(vobs, sizes, pgcs, chs, min_chapter, tol):
    """Chapter start times of one title, in seconds from the first picture of the title.
    The playing order of the cells comes from the PGC. The time of each cell is the time of the previous one plus its
    length: the difference of the video timestamps (PTS) in the VOB files when they run on without a break, otherwise
    the length from the IFO. Some discs restart the timestamps in the middle of the title, or start with cells of a
    fraction of a second that all point to one place (dummy cells); both are handled here."""
    order = []
    for pgcn, _ in chs:
        if pgcn not in order:
            order.append(pgcn)
    cells, seen = [], set()
    for pgcn in order:
        for ci, c in enumerate(pgcs[pgcn - 1]['cells'], 1):
            dummy = c['dur'] < min_chapter or c['first'] in seen
            seen.add(c['first'])
            cells.append(dict(c, pgc=pgcn, idx=ci, dummy=dummy))
    t, prev, prev_pts = 0.0, None, None
    for c in cells:
        if c['dummy']:
            continue
        pts = _pts_at(vobs, c['first'], sizes)
        if prev is not None:
            d = pts - prev_pts
            step = d if abs(d - prev['dur']) <= tol else prev['dur']
            c['jump'] = step is not d
            t += step
        c['t'], c['pts'] = t, pts
        prev, prev_pts = c, pts
    real = [c for c in cells if not c['dummy']]
    if not real:
        return [], 0.0, []
    chap = []
    for pgcn, pgn in chs:
        pg = pgcs[pgcn - 1]
        first = pg['prog'][pgn - 1]
        nxt = pg['prog'][pgn] if pgn < len(pg['prog']) else len(pg['cells']) + 1
        mine = [c for c in real if c['pgc'] == pgcn and first <= c['idx'] < nxt]
        if mine and sum(c['dur'] for c in mine) >= min_chapter:
            chap.append(mine[0]['t'])
    length = real[-1]['t'] + real[-1]['dur']
    return chap, length, real


def _file_starts(vobs, sizes, real):
    """Time of the start of each VOB file within the title (for playing a track from the right file)."""
    out, acc = [], 0
    for (n, p), sz in zip(vobs, sizes):
        sec = acc // SECTOR
        cell = next((c for c in real if c['first'] <= sec <= c['last']), None)
        if cell is None:
            cell = min(real, key=lambda c: abs(c['first'] - sec))
        frac = (sec - cell['first']) / max(1, cell['last'] - cell['first'] + 1)
        out.append({'name': os.path.basename(p), 'start': round(max(0.0, cell['t'] + frac * cell['dur']), 3)})
        acc += sz
    return out


def scan_dvd(video_ts, ffprobe, opts=None):
    """Every part (title) of the disc that is long enough, each with its own chapters. A part belongs to one title set,
    its times are relative to the start of that title set."""
    opts = opts or {}
    min_part = float(opts.get('dvd_min_part_s', 900))
    min_chapter = float(opts.get('dvd_min_chapter_s', 2))
    tol = float(opts.get('dvd_time_tolerance_s', 2))
    sets = _title_sets(video_ts)
    if not sets:
        raise RuntimeError('no VTS_xx_n.VOB files in %s' % video_ts)
    parts, skipped, audio = [], [], []
    for vts in sorted(sets):
        vobs = sets[vts]
        ifo_name = next((f for f in os.listdir(video_ts) if f.upper() == 'VTS_%02d_0.IFO' % vts), None)
        if ifo_name is None:
            skipped.append((vts, vobs))
            continue
        ifo = open(os.path.join(video_ts, ifo_name), 'rb').read()
        if ifo[:12] != b'DVDVIDEO-VTS':
            raise RuntimeError('VTS_%02d_0.IFO is not a title set IFO' % vts)
        sizes = [os.path.getsize(p) for _, p in vobs]
        pgcs = _vts_pgcs(ifo)
        cands = []
        for ti, chs in enumerate(_vts_titles(ifo), 1):
            if not chs:
                continue
            marks, length, real = _timeline(vobs, sizes, pgcs, chs, min_chapter, tol)
            if not marks:
                continue
            cands.append({'title': ti, 'marks': marks, 'length': length, 'real': real, 'cells': set(c['first'] for c in real)})
        # several titles of one title set that cover the same cells are the same content (for example a play-all
        # title and a title without the intro); keep the longest
        keep = []
        for c in sorted(cands, key=lambda c: -c['length']):
            if not any(c['cells'] & k['cells'] for k in keep):
                keep.append(c)
        for c in sorted(keep, key=lambda c: c['title']):
            if c['length'] < min_part:
                continue
            marks = c['marks']
            bad = [i + 1 for i in range(len(marks)) if marks[i] < -0.001 or (i and marks[i] <= marks[i - 1] + 0.001)]
            if bad:
                raise RuntimeError('Unreliable chapter times in title set VTS_%02d (chapter %d starts at %.1f s, not after the previous one); '
                                   'the disc layout is not understood, so no chapters are shown' % (vts, bad[0], marks[bad[0] - 1]))
            files = _file_starts(vobs, sizes, c['real'])
            if not audio:
                audio = _vts_audio(ifo, vobs, ffprobe)
            parts.append({'vts': vts, 'title': c['title'], 'length': c['length'], 'marks': marks, 'vobs': files,
                          'jumps': sum(1 for x in c['real'] if x.get('jump'))})
    if not parts:
        if skipped:
            vts, vobs = skipped[0]
            raise RuntimeError('Incomplete DVD folder: VTS_%02d_0.IFO is missing (only %s found), so chapters cannot be read'
                               % (vts, ', '.join(os.path.basename(p) for _, p in vobs)))
        raise RuntimeError('no title of at least %d seconds found on this DVD' % min_part)
    tracks, n = [], 0
    for pi, pt in enumerate(parts, 1):
        for i, st in enumerate(pt['marks']):
            n += 1
            en = pt['marks'][i + 1] if i + 1 < len(pt['marks']) else None
            tracks.append({'n': n, 'title': 'Chapter %d' % (i + 1), 'start': round(st, 3),
                           'end': None if en is None else round(en, 3), 'part': pi, 'vts': pt['vts'], 'plen': round(pt['length'], 3)})
    plist = [{'part': i, 'vts': p['vts'], 'title': p['title'], 'length': round(p['length'], 3), 'vobs': p['vobs'], 'timestamp_breaks': p['jumps']} for i, p in enumerate(parts, 1)]
    return {'length': sum(p['length'] for p in parts), 'tracks': tracks, 'audio': audio, 'vts': parts[0]['vts'],
            'vobs': parts[0]['vobs'], 'parts': plist, 'video': 'DVD'}


def scan_concert(kind, path, ffprobe, opts=None):
    if kind == 'mkv':
        return scan_mkv(path, ffprobe)
    if kind == 'bluray':
        return scan_bluray(path, ffprobe)
    return scan_dvd(path, ffprobe, opts)
