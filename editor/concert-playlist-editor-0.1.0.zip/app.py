"""Concert playlist editor: local web app. See SPEC.md section 12."""
import hashlib
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

import scanner

HERE = os.path.dirname(os.path.abspath(__file__))
VERSION = open(os.path.join(HERE, 'VERSION')).read().strip()
LOCK = threading.RLock()
STATE = {'scan': {'running': False, 'done': 0, 'total': 0, 'message': '', 'last': ''}, 'errors': []}
DATA = {}
S = {}
INDEX_SCHEMA = 4
INDEX = {'schema': INDEX_SCHEMA, 'concerts': {}}
CHOICES = {}
NAMES = {}
_last_pub = 0.0


def data_dir():
    if len(sys.argv) > 1 and sys.argv[1] != '--no-browser':
        return sys.argv[1]
    base = os.environ.get('APPDATA') or os.path.expanduser('~/.config')
    return os.path.join(base, 'ConcertPlaylistEditor')


def jload(path, default):
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except (OSError, ValueError) as e:
        log('ERROR', 'Cannot read %s: %s' % (path, e))
        return default


def jsave(path, obj):
    tmp = path + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)
    os.replace(tmp, path)


def logfile():
    return os.path.join(DATA['dir'], 'concert_editor.log')


def log(level, msg):
    global _last_pub
    line = '%s %-5s %s' % (time.strftime('%Y-%m-%d %H:%M:%S'), level, msg)
    try:
        p = logfile()
        if os.path.exists(p) and os.path.getsize(p) > S.get('log_max_kb', 512) * 1024:
            os.replace(p, p + '.old')
        with open(p, 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except Exception:
        pass
    print(line, flush=True)
    if level in ('ERROR', 'WARN'):
        with LOCK:
            STATE['errors'].append(line)
            del STATE['errors'][:-50]
    if time.time() - _last_pub > S.get('log_publish_s', 5) or level == 'ERROR':
        publish_log()


def publish_log():
    global _last_pub
    _last_pub = time.time()
    d = playlists_dir()
    if d and os.path.isdir(d):
        try:
            shutil.copyfile(logfile(), os.path.join(d, 'concert_editor.log'))
        except OSError:
            pass


def load_settings():
    S.clear()
    S.update(jload(os.path.join(HERE, 'defaults.json'), {}))
    S.update(jload(os.path.join(DATA['dir'], 'settings.json'), {}))


def playlists_dir():
    if S.get('playlists_dir'):
        return S['playlists_dir']
    if S.get('library_root'):
        return os.path.join(S['library_root'], *S['playlists_subfolder'].split('/'))
    return ''


def rel(path):
    return os.path.relpath(path, S['library_root']).replace('\\', '/')


def cid(relpath):
    return hashlib.sha1(relpath.encode('utf-8')).hexdigest()[:12]


def signature(kind, path):
    try:
        if kind == 'mkv':
            st = os.stat(path)
            return '%d-%d' % (st.st_size, int(st.st_mtime))
        if kind == 'dvd':
            st = os.stat(path)
            return 'd%d-%d' % (st.st_mtime, len(os.listdir(path)))
        st = os.stat(os.path.join(path, 'PLAYLIST'))
        return 'b%d' % st.st_mtime
    except OSError as e:
        return 'err-%s' % e


def category_of(relpath):
    top = relpath.split('/')[0].lower()
    for c in S['categories']:
        if c['folder'].replace('\\', '/').split('/')[0].lower() == top:
            return c['name']
    return None


def scan_one(folder, kind, path):
    r = rel(path)
    key = cid(r)
    sig = signature(kind, path)
    with LOCK:
        old = INDEX['concerts'].get(key)
    if old and old.get('sig') == sig and not old.get('error'):
        return key, old
    title = os.path.splitext(os.path.basename(path))[0] if kind == 'mkv' else os.path.basename(folder)
    if re.match(r'^(disk|disc|cd|dvd)[\s_-]*\d+$', title, re.I):
        title = '%s - %s' % (os.path.basename(os.path.dirname(folder)), title)
    frel = rel(folder)
    parts = frel.split('/')
    entry = {'id': key, 'path': r, 'folder': frel, 'kind': kind, 'title': title, 'sig': sig,
             'artist': parts[-2] if len(parts) > 2 else '', 'category': category_of(r),
             'poster': scanner.find_poster(folder, S['poster_names'])}
    if entry['poster']:
        entry['poster'] = frel + '/' + entry['poster']
    try:
        entry.update(scanner.scan_concert(kind, path, S['ffprobe_path']))
        for a in entry['audio']:
            a['label'] = audio_label(a)
    except Exception as e:
        entry['error'] = str(e)
        entry.setdefault('tracks', [])
        entry.setdefault('audio', [])
        log('ERROR', 'Scan of %s failed: %s' % (r, e))
    return key, entry


def audio_label(a):
    ch = {1: '1.0', 2: '2.0', 6: '5.1', 8: '7.1'}.get(a['channels'], '%dch' % a['channels'])
    parts = [a['codec'].upper(), ch]
    if a.get('language'):
        parts.append(a['language'])
    if a.get('title'):
        parts.append(a['title'])
    return ' '.join(parts)


def default_audio(audio):
    order = [c.lower() for c in S['audio_codec_order']]

    def rank(a):
        c = a['codec'].lower()
        pos = next((i for i, o in enumerate(order) if c.startswith(o)), len(order))
        return (-a['channels'], pos, a['position'])
    return sorted(audio, key=rank)[0]['position'] if audio else None


def scan_all():
    with LOCK:
        if STATE['scan']['running']:
            return
        STATE['scan'] = {'running': True, 'done': 0, 'total': 0, 'message': 'Looking for concerts', 'last': STATE['scan'].get('last', '')}
    try:
        root = S['library_root']
        if not root or not os.path.isdir(root):
            raise RuntimeError('Library root "%s" is not reachable. Set it in Settings.' % root)
        found = []
        for c in S['categories']:
            base = os.path.join(root, *c['folder'].replace('\\', '/').split('/'))
            if not os.path.isdir(base):
                log('WARN', 'Category folder not found: %s' % base)
                continue
            found.extend(scanner.discover(base, log))
        with LOCK:
            STATE['scan'].update(total=len(found), message='Reading concerts')
        log('INFO', 'Scan: %d concert(s) found' % len(found))
        result = {}

        def work(item):
            k, e = scan_one(*item)
            with LOCK:
                STATE['scan']['done'] += 1
                INDEX['concerts'][k] = e
                if STATE['scan']['done'] % int(S['index_save_every']) == 0:
                    jsave(os.path.join(DATA['dir'], 'index.json'), INDEX)
            return k, e
        with ThreadPoolExecutor(max_workers=int(S['scan_workers'])) as ex:
            for k, e in ex.map(work, found):
                result[k] = e
        with LOCK:
            INDEX['concerts'] = result
            jsave(os.path.join(DATA['dir'], 'index.json'), INDEX)
        errs = sum(1 for e in result.values() if e.get('error'))
        log('INFO', 'Scan finished: %d concert(s), %d with errors' % (len(result), errs))
        STATE['scan']['last'] = '%s: %d concerts, %d with errors' % (time.strftime('%H:%M'), len(result), errs)
    except Exception as e:
        log('ERROR', 'Scan failed: %s' % e)
    finally:
        with LOCK:
            STATE['scan']['running'] = False
            STATE['scan']['message'] = ''
            STATE['scan']['last'] = STATE['scan'].get('last') or ''
        publish_log()


def public_concert(e, full=False):
    d = {'id': e['id'], 'title': e['title'], 'artist': e.get('artist', ''), 'kind': e['kind'],
         'category': e.get('category'), 'poster': bool(e.get('poster')), 'error': e.get('error'), 'length': e.get('length')}
    if full:
        names = NAMES.get(e['id'], {})
        d['video'] = e.get('video', '')
        d['audio'] = e.get('audio', [])
        d['audio_choice'] = CHOICES.get(e['id'], default_audio(e.get('audio', [])))
        d['audio_default'] = default_audio(e.get('audio', []))
        d['tracks'] = [dict(t, title=names.get(str(t['n']), t['title']), renamable=e['kind'] != 'mkv') for t in e.get('tracks', [])]
    return d


# ---- playlists ------------------------------------------------------------------

def safe_name(name):
    return re.sub(r'[\\/:*?"<>|]', '_', name).strip().strip('.')


def playlist_path(name):
    return os.path.join(playlists_dir(), safe_name(name) + '.json')


def list_playlists():
    d = playlists_dir()
    out = []
    if d and os.path.isdir(d):
        for f in sorted(os.listdir(d), key=str.lower):
            if f.lower().endswith('.json'):
                p = jload(os.path.join(d, f), None)
                if isinstance(p, dict) and 'entries' in p:
                    out.append({'name': p.get('name', f[:-5]), 'count': len(p['entries'])})
    return out


def read_playlist(name):
    p = jload(playlist_path(name), None)
    if p is None:
        raise KeyError('Playlist "%s" not found' % name)
    return p


def write_playlist(p):
    d = playlists_dir()
    if not d:
        raise RuntimeError('Playlists folder is not set. Set the library root or playlists folder in Settings.')
    os.makedirs(d, exist_ok=True)
    jsave(playlist_path(p['name']), p)


def make_entry(cidv, n):
    e = INDEX['concerts'][cidv]
    t = next(t for t in e['tracks'] if t['n'] == n)
    names = NAMES.get(cidv, {})
    audio = None
    pos = CHOICES.get(cidv, default_audio(e.get('audio', [])))
    if pos is not None:
        a = next((a for a in e['audio'] if a['position'] == pos), None)
        if a:
            audio = {k: a[k] for k in ('position', 'codec', 'profile', 'channels', 'language', 'title')}
    last = n == e['tracks'][-1]['n']
    ent = {'concert': e['title'], 'title': names.get(str(n), t['title']), 'source': e['kind'], 'path': e['path'],
           'start': t['start'], 'end': None if last else t['end'], 'audio': audio}
    if e['kind'] == 'bluray':
        ent['playlist'] = e['playlist']
    if e['kind'] == 'dvd':
        ent['vts'] = e['vts']
    return ent


def play_now(cidv, n):
    """Start one track in VLC on this PC (start and stop times, chosen audio stream)."""
    e = INDEX['concerts'][cidv]
    ent = make_entry(cidv, n)
    root = S['library_root']
    full = os.path.join(root, *e['path'].split('/'))
    if e['kind'] == 'mkv':
        target = full
    elif e['kind'] == 'dvd':
        vobs = e['vobs']
        vob = next((c for c in reversed(vobs) if c['start'] <= ent['start'] + 0.001), vobs[0])
        nxt = vobs[vobs.index(vob) + 1]['start'] if vob is not vobs[-1] else None
        target = os.path.join(full, vob['name'])
        ent = dict(ent, start=round(ent['start'] - vob['start'], 3),
                   end=None if ent['end'] is None or (nxt is not None and ent['end'] > nxt) else round(ent['end'] - vob['start'], 3))
    else:
        clips = e['clips']
        clip = next((c for c in reversed(clips) if c['offset'] <= ent['start'] + 0.001), clips[0])
        target = os.path.join(full, 'STREAM', clip['name'] + '.m2ts')
        ent = dict(ent, start=round(ent['start'] - clip['offset'], 3),
                   end=None if ent['end'] is None else round(min(ent['end'] - clip['offset'], clip['dur']), 3))
    cmd = [S['vlc_path'], '--start-time=%s' % ent['start']]
    if ent['end'] is not None:
        cmd.append('--stop-time=%s' % ent['end'])
    if ent['audio']:
        cmd.append('--audio-track=%d' % ent['audio']['position'])
    cmd += list(S.get('vlc_extra_args') or []) + [target]
    log('INFO', 'Play now: %s' % ' '.join(cmd))
    try:
        subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError as err:
        raise RuntimeError('Cannot start VLC (%s): %s. Set the VLC program in Settings.' % (S['vlc_path'], err))
    return {'title': ent['title'], 'start': ent['start'], 'end': ent['end'], 'audio': ent['audio']}


# ---- HTTP -----------------------------------------------------------------------

class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send_json(self, obj, code=200):
        b = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get('Content-Length') or 0)
        return json.loads(self.rfile.read(n) or b'{}')

    def fail(self, e, code=400):
        import traceback
        log('ERROR', '%s %s: %s' % (self.command, self.path, e))
        if code >= 500:
            log('ERROR', traceback.format_exc().strip())
        self.send_json({'error': str(e)}, code)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == '/':
                return self.send_file(os.path.join(HERE, 'static', 'index.html'))
            if u.path == '/api/state':
                with LOCK:
                    cats = [c['name'] for c in S['categories']]
                    return self.send_json({'version': VERSION, 'scan': STATE['scan'], 'errors': STATE['errors'][-20:],
                                           'categories': cats, 'columns': S['poster_columns'],
                                           'configured': bool(S.get('library_root')), 'count': len(INDEX['concerts'])})
            if u.path == '/api/settings':
                return self.send_json(dict(S, version=VERSION, log_file=logfile()))
            if u.path == '/api/concerts':
                with LOCK:
                    lst = [public_concert(e) for e in INDEX['concerts'].values() if e.get('category') == q.get('category')]
                lst.sort(key=lambda c: (re.sub(r'^the\s+', '', (c['artist'] or c['title']).lower()), c['title'].lower()))
                return self.send_json(lst)
            if u.path == '/api/search':
                t = q.get('q', '').lower()
                with LOCK:
                    lst = [public_concert(e) for e in INDEX['concerts'].values()
                           if t and (t in e['title'].lower() or any(t in x['title'].lower() for x in e['tracks']))]
                return self.send_json(lst[:60])
            if u.path == '/api/concert':
                with LOCK:
                    return self.send_json(public_concert(INDEX['concerts'][q['id']], True))
            if u.path == '/api/poster':
                with LOCK:
                    e = INDEX['concerts'][q['id']]
                if not e.get('poster'):
                    return self.send_json({'error': 'no poster'}, 404)
                return self.send_file(os.path.join(S['library_root'], *e['poster'].split('/')), cache=True)
            if u.path == '/api/playlists':
                return self.send_json(list_playlists())
            if u.path == '/api/playlist':
                return self.send_json(read_playlist(q['name']))
            self.send_json({'error': 'not found'}, 404)
        except KeyError as e:
            self.fail('Not found: %s' % e, 404)
        except Exception as e:
            self.fail(e, 500)

    def do_POST(self):
        u = urlparse(self.path)
        try:
            b = self.body()
            if u.path == '/api/settings':
                new = {k: v for k, v in b.items() if k in S and k not in ('version', 'log_file')}
                cur = jload(os.path.join(DATA['dir'], 'settings.json'), {})
                cur.update(new)
                jsave(os.path.join(DATA['dir'], 'settings.json'), cur)
                load_settings()
                log('INFO', 'Settings saved')
                return self.send_json({'ok': True})
            if u.path == '/api/play':
                with LOCK:
                    return self.send_json(play_now(b['id'], int(b['n'])))
            if u.path == '/api/clientlog':
                log('ERROR', 'Browser error: %s' % str(b.get('message'))[:600])
                return self.send_json({'ok': True})
            if u.path == '/api/rescan':
                threading.Thread(target=scan_all, daemon=True).start()
                return self.send_json({'ok': True})
            if u.path == '/api/audio':
                CHOICES[b['id']] = int(b['position'])
                jsave(os.path.join(DATA['dir'], 'choices.json'), CHOICES)
                return self.send_json({'ok': True})
            if u.path == '/api/rename':
                NAMES.setdefault(b['id'], {})[str(b['n'])] = b['title'].strip()
                jsave(os.path.join(DATA['dir'], 'names.json'), NAMES)
                return self.send_json({'ok': True})
            if u.path == '/api/playlist/add':
                name = b['playlist'].strip()
                if not name:
                    raise ValueError('Enter a playlist name')
                with LOCK:
                    ent = make_entry(b['id'], int(b['n']))
                try:
                    p = read_playlist(name)
                except KeyError:
                    p = {'name': name, 'entries': []}
                    if b.get('new') is False:
                        raise
                if b.get('new') and os.path.exists(playlist_path(name)):
                    raise ValueError('A playlist named "%s" already exists' % name)
                dup = any(x['path'] == ent['path'] and x['start'] == ent['start'] and x.get('playlist') == ent.get('playlist') for x in p['entries'])
                if not dup:
                    p['entries'].append(ent)
                    write_playlist(p)
                    log('INFO', 'Added "%s" (%s) to playlist "%s"' % (ent['title'], ent['concert'], name))
                return self.send_json({'ok': True, 'added': not dup})
            if u.path == '/api/playlist/save':
                write_playlist(b)
                log('INFO', 'Playlist "%s" saved (%d entries)' % (b['name'], len(b['entries'])))
                return self.send_json({'ok': True})
            if u.path == '/api/playlist/rename':
                p = read_playlist(b['name'])
                new = b['new'].strip()
                if not new or (os.path.exists(playlist_path(new)) and new.lower() != b['name'].lower()):
                    raise ValueError('Enter a new, unused name')
                os.remove(playlist_path(b['name']))
                p['name'] = new
                write_playlist(p)
                return self.send_json({'ok': True})
            if u.path == '/api/playlist/delete':
                os.remove(playlist_path(b['name']))
                log('INFO', 'Playlist "%s" deleted' % b['name'])
                return self.send_json({'ok': True})
            self.send_json({'error': 'not found'}, 404)
        except KeyError as e:
            self.fail('Not found: %s' % e, 404)
        except Exception as e:
            self.fail(e)

    def send_file(self, path, cache=False):
        with open(path, 'rb') as f:
            b = f.read()
        self.send_response(200)
        self.send_header('Content-Type', mimetypes.guess_type(path)[0] or 'application/octet-stream')
        self.send_header('Content-Length', str(len(b)))
        if cache:
            self.send_header('Cache-Control', 'max-age=86400')
        self.end_headers()
        self.wfile.write(b)


def startup_checks():
    log('INFO', 'Environment: Python %s, %s, ffprobe=%s, vlc=%s' % (sys.version.split()[0], sys.platform, S.get('ffprobe_path'), S.get('vlc_path')))
    log('INFO', 'Settings: library_root=%s, playlists_dir=%s, columns=%s, categories=%s' % (
        S.get('library_root'), playlists_dir(), S.get('poster_columns'), [c['name'] for c in S['categories']]))
    if not shutil.which(S['ffprobe_path']) and not os.path.isfile(S['ffprobe_path']):
        log('ERROR', 'ffprobe not found (%s). Concerts cannot be scanned. Set the ffprobe program in Settings.' % S['ffprobe_path'])
    if not S.get('library_root'):
        log('WARN', 'Library root is not set. Set it in Settings.')
    elif not os.path.isdir(S['library_root']):
        log('ERROR', 'Library root %s is not reachable.' % S['library_root'])
    d = playlists_dir()
    if d:
        try:
            os.makedirs(d, exist_ok=True)
            t = os.path.join(d, '.write_test')
            open(t, 'w').close()
            os.remove(t)
        except OSError as err:
            log('ERROR', 'Playlists folder %s is not writable: %s' % (d, err))
    if not (os.path.isfile(S['vlc_path']) or shutil.which(S['vlc_path'])):
        log('WARN', 'VLC not found at %s; Play now will not work until it is set in Settings.' % S['vlc_path'])


def install_hooks():
    def eh(t, v, tb):
        import traceback
        log('ERROR', 'Unhandled exception: %s' % ''.join(traceback.format_exception(t, v, tb)).strip())
    sys.excepthook = eh

    def th(a):
        import traceback
        log('ERROR', 'Unhandled exception in thread %s: %s' % (a.thread.name if a.thread else '?', ''.join(traceback.format_exception(a.exc_type, a.exc_value, a.exc_traceback)).strip()))
    threading.excepthook = th


def main():
    DATA['dir'] = data_dir()
    os.makedirs(DATA['dir'], exist_ok=True)
    load_settings()
    INDEX.update(jload(os.path.join(DATA['dir'], 'index.json'), {'concerts': {}}))
    if INDEX.get('schema') != INDEX_SCHEMA:
        INDEX.clear()
        INDEX.update({'schema': INDEX_SCHEMA, 'concerts': {}})
    CHOICES.update(jload(os.path.join(DATA['dir'], 'choices.json'), {}))
    NAMES.update(jload(os.path.join(DATA['dir'], 'names.json'), {}))
    install_hooks()
    log('INFO', 'Concert playlist editor %s starting, data in %s' % (VERSION, DATA['dir']))
    startup_checks()
    if S.get('library_root') and S.get('rescan_on_start'):
        threading.Thread(target=scan_all, daemon=True).start()
    srv = ThreadingHTTPServer(('127.0.0.1', int(S['port'])), H)
    url = 'http://127.0.0.1:%d/' % srv.server_address[1]
    log('INFO', 'Listening on %s' % url)
    if S.get('open_browser') and '--no-browser' not in sys.argv:
        webbrowser.open(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        publish_log()


if __name__ == '__main__':
    main()
