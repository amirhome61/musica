"""Concert scanner: finds concerts under the library root and reads tracks and audio streams.

Read-only on the library. No values are hard-coded here: everything comes from the settings dict.
"""
import json
import os
import re
import struct
import subprocess

VIDEO_EXT = ('.mkv', '.mp4', '.avi', '.m4v', '.ts', '.m2ts')
SECTOR = 2048


def _run_ffprobe(ffprobe, path, args):
    cmd = [ffprobe, '-v', 'error', '-of', 'json'] + args + [path]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=120)
    if r.returncode != 0:
        raise RuntimeError('ffprobe failed for %s: %s' % (path, r.stderr.strip()[:300]))
    return json.loads(r.stdout or '{}')


def _audio_from_ffprobe(data):
    out = []
    for s in data.get('streams', []):
        if s.get('codec_type') != 'audio':
            continue
        tags = s.get('tags') or {}
        prof = s.get('profile') or ''
        out.append({
            'position': len(out),
            'codec': s.get('codec_name', ''),
            'profile': prof,
            'channels': int(s.get('channels') or 0),
            'language': (tags.get('language') or tags.get('LANGUAGE') or '').lower(),
            'title': tags.get('title') or tags.get('TITLE') or '',
            'default': bool((s.get('disposition') or {}).get('default')),
        })
    return out


def find_poster(folder, names):
    try:
        files = {f.lower(): f for f in os.listdir(folder)}
    except OSError:
        return None
    for n in names:
        if n.startswith('*'):
            suf = n[1:].lower()
            for low, f in sorted(files.items()):
                if low.endswith(suf):
                    return f
        elif n.lower() in files:
            return files[n.lower()]
    return None


def discover(root, log):
    """Yield (folder, kind, path) for every concert below root. kind: mkv, dvd, bluray."""
    stack = [root]
    while stack:
        folder = stack.pop()
        try:
            entries = sorted(os.scandir(folder), key=lambda e: e.name.lower())
        except OSError as e:
            log('ERROR', 'Cannot list %s: %s' % (folder, e))
            continue
        names = {e.name.upper(): e for e in entries}
        if 'VIDEO_TS' in names and names['VIDEO_TS'].is_dir():
            yield folder, 'dvd', names['VIDEO_TS'].path
            continue
        if 'BDMV' in names and names['BDMV'].is_dir():
            yield folder, 'bluray', names['BDMV'].path
            continue
        vids = [e for e in entries if e.is_file() and e.name.lower().endswith(VIDEO_EXT)]
        for v in vids:
            yield folder, 'mkv', v.path
        for e in entries:
            if e.is_dir() and not e.name.startswith(('_', '.')) and e.name.lower() not in ('extrafanart', 'extrathumbs', 'extras', 'sample'):
                stack.append(e.path)


def scan_mkv(path, ffprobe):
    d = _run_ffprobe(ffprobe, path, ['-show_chapters', '-show_streams', '-show_format'])
    length = float((d.get('format') or {}).get('duration') or 0)
    tracks = []
    for i, c in enumerate(d.get('chapters', []), 1):
        t = (c.get('tags') or {}).get('title') or 'Chapter %d' % i
        tracks.append({'n': i, 'title': t, 'start': round(float(c['start_time']), 3), 'end': round(float(c['end_time']), 3)})
    if not tracks:
        tracks = [{'n': 1, 'title': 'Whole concert', 'start': 0.0, 'end': None}]
    video = next((s for s in d.get('streams', []) if s.get('codec_type') == 'video'), {})
    return {'length': length, 'tracks': tracks, 'audio': _audio_from_ffprobe(d),
            'video': '%sx%s %s' % (video.get('width', '?'), video.get('height', '?'), video.get('codec_name', ''))}


# ---- Blu-ray ----------------------------------------------------------------

def parse_mpls(path):
    d = open(path, 'rb').read()
    pl_start, mark_start = struct.unpack('>II', d[8:16])
    n_items = struct.unpack('>H', d[pl_start + 6:pl_start + 8])[0]
    p = pl_start + 10
    items, acc = [], 0.0
    for _ in range(n_items):
        ln = struct.unpack('>H', d[p:p + 2])[0]
        clip = d[p + 2:p + 7].decode('ascii', 'replace')
        tin, tout = struct.unpack('>II', d[p + 14:p + 22])
        items.append((clip, tin, tout, acc))
        acc += (tout - tin) / 45000.0
        p += 2 + ln
    nm = struct.unpack('>H', d[mark_start + 4:mark_start + 6])[0]
    marks = []
    for k in range(nm):
        q = mark_start + 6 + 14 * k
        if d[q + 1] == 1:
            ref = struct.unpack('>H', d[q + 2:q + 4])[0]
            ts = struct.unpack('>I', d[q + 4:q + 8])[0]
            if ref < len(items):
                _, tin, _, a = items[ref]
                marks.append(a + (ts - tin) / 45000.0)
    return items, marks, acc


def scan_bluray(bdmv, ffprobe):
    pdir = os.path.join(bdmv, 'PLAYLIST')
    best = None
    for f in sorted(os.listdir(pdir)):
        if not f.lower().endswith('.mpls'):
            continue
        items, marks, total = parse_mpls(os.path.join(pdir, f))
        if best is None or total > best[3]:
            best = (f, items, marks, total)
    if best is None:
        raise RuntimeError('no .mpls playlists in %s' % pdir)
    f, items, marks, total = best
    marks = sorted(m for m in marks if m < total - 1.0)
    if not marks or marks[0] > 1.0:
        marks.insert(0, 0.0)
    tracks = []
    for i, st in enumerate(marks):
        en = marks[i + 1] if i + 1 < len(marks) else round(total, 3)
        tracks.append({'n': i + 1, 'title': 'Chapter %d' % (i + 1), 'start': round(st, 3), 'end': round(en, 3)})
    clip = os.path.join(bdmv, 'STREAM', items[0][0] + '.m2ts')
    d = _run_ffprobe(ffprobe, clip, ['-show_streams'])
    video = next((s for s in d.get('streams', []) if s.get('codec_type') == 'video'), {})
    return {'length': total, 'tracks': tracks, 'audio': _audio_from_ffprobe(d),
            'playlist': int(os.path.splitext(f)[0]),
            'clips': [{'name': c, 'offset': round(a, 3), 'dur': round((o - i) / 45000.0, 3)} for c, i, o, a in items], 'video': '%sx%s %s' % (video.get('width', '?'), video.get('height', '?'), video.get('codec_name', ''))}


# ---- DVD ----------------------------------------------------------------------

DVD_AUDIO_CODING = {0: 'ac3', 2: 'mp1', 3: 'mp2', 4: 'pcm', 6: 'dts'}


def _bcd_time(b):
    def f(x):
        return (x >> 4) * 10 + (x & 15)
    fr = b[3]
    rate = 25.0 if (fr >> 6) == 1 else 29.97
    return f(b[0]) * 3600 + f(b[1]) * 60 + f(b[2]) + f(fr & 0x3F) / rate


def _title_sets(video_ts):
    sets = {}
    for f in os.listdir(video_ts):
        m = re.match(r'VTS_(\d\d)_(\d)\.VOB$', f.upper())
        if m and m.group(2) != '0':
            vts = int(m.group(1))
            sets.setdefault(vts, []).append((int(m.group(2)), os.path.join(video_ts, f)))
    for k in sets:
        sets[k].sort()
    return sets


def _pts_at(vobs, sector, sizes):
    """Video PTS (seconds) at or after the given sector of the concatenated VOB files."""
    off = sector * SECTOR
    for (n, path), size in zip(vobs, sizes):
        if off < size:
            break
        off -= size
    else:
        raise RuntimeError('sector %d beyond the title set' % sector)
    with open(path, 'rb') as fh:
        fh.seek(off)
        buf = fh.read(SECTOR * 400)
    pos = 0
    while True:
        pos = buf.find(b'\x00\x00\x01\xe0', pos)
        if pos < 0 or pos + 14 > len(buf):
            raise RuntimeError('no video PTS found near sector %d in %s' % (sector, path))
        if buf[pos + 7] & 0x80:
            b = buf[pos + 9:pos + 14]
            pts = ((b[0] >> 1) & 7) << 30 | b[1] << 22 | (b[2] >> 1) << 15 | b[3] << 7 | b[4] >> 1
            return pts / 90000.0
        pos += 4


def scan_dvd(video_ts, ffprobe):
    sets = _title_sets(video_ts)
    if not sets:
        raise RuntimeError('no VTS_xx_n.VOB files in %s' % video_ts)
    vts = max(sets, key=lambda k: sum(os.path.getsize(p) for _, p in sets[k]))
    vobs = sets[vts]
    sizes = [os.path.getsize(p) for _, p in vobs]
    ifo_name = next((f for f in os.listdir(video_ts) if f.upper() == 'VTS_%02d_0.IFO' % vts), None)
    if ifo_name is None:
        raise RuntimeError('Incomplete DVD folder: VTS_%02d_0.IFO is missing (only %s found), so chapters cannot be read'
                           % (vts, ', '.join(os.path.basename(p) for _, p in vobs)))
    ifo = open(os.path.join(video_ts, ifo_name), 'rb').read()
    if ifo[:12] != b'DVDVIDEO-VTS':
        raise RuntimeError('VTS_%02d_0.IFO is not a title set IFO' % vts)
    # audio attributes
    naud = struct.unpack('>H', ifo[0x202:0x204])[0]
    audio = []
    for i in range(min(naud, 8)):
        a = ifo[0x204 + 8 * i:0x204 + 8 * i + 8]
        coding = a[0] >> 5
        lang = a[2:4].decode('ascii', 'replace').strip('\x00 ').lower() if (a[0] >> 2) & 3 == 1 else ''
        audio.append({'position': i, 'codec': DVD_AUDIO_CODING.get(coding, 'unknown'), 'profile': '',
                      'channels': (a[1] & 7) + 1, 'language': lang, 'title': '', 'default': i == 0})
    # The IFO may list more audio entries than the VOBs carry (padding); keep as many as ffprobe finds in the VOBs.
    try:
        real = _audio_from_ffprobe(_run_ffprobe(ffprobe, vobs[0][1], ['-show_streams']))
    except RuntimeError:
        real = []
    if real:
        for i, r in enumerate(real):
            if i < len(audio):
                r['language'] = r['language'] or audio[i]['language']
                r['channels'] = r['channels'] or audio[i]['channels']
        audio = real
    # PGC list, choose the longest
    pgcit = struct.unpack('>I', ifo[0xCC:0xD0])[0] * SECTOR
    npgc = struct.unpack('>H', ifo[pgcit:pgcit + 2])[0]
    best = None
    for k in range(npgc):
        e = pgcit + 8 + 8 * k
        off = pgcit + struct.unpack('>I', ifo[e + 4:e + 8])[0]
        dur = _bcd_time(ifo[off + 4:off + 8])
        if best is None or dur > best[1]:
            best = (off, dur)
    pgc, dur = best
    nprog = ifo[pgc + 2]
    ncell = ifo[pgc + 3]
    pmap = struct.unpack('>H', ifo[pgc + 0xE6:pgc + 0xE8])[0]
    cpb = struct.unpack('>H', ifo[pgc + 0xE8:pgc + 0xEA])[0]
    entry_cells = [ifo[pgc + pmap + i] for i in range(nprog)]
    cells = []
    for c in range(ncell):
        q = pgc + cpb + 24 * c
        first = struct.unpack('>I', ifo[q + 8:q + 12])[0]
        cells.append(first)
    base = _pts_at(vobs, 0, sizes)
    marks = []
    for ec in entry_cells:
        marks.append(_pts_at(vobs, cells[ec - 1], sizes) - base)
    tracks = []
    for i, st in enumerate(marks):
        en = marks[i + 1] if i + 1 < len(marks) else None
        tracks.append({'n': i + 1, 'title': 'Chapter %d' % (i + 1), 'start': round(st, 3), 'end': None if en is None else round(en, 3)})
    files, acc = [], 0
    for (n, p), sz in zip(vobs, sizes):
        files.append({'name': os.path.basename(p), 'start': round(_pts_at(vobs, acc // SECTOR, sizes) - base, 3)})
        acc += sz
    return {'length': dur, 'tracks': tracks, 'audio': audio, 'vts': vts, 'vobs': files, 'video': 'DVD'}


def scan_concert(kind, path, ffprobe):
    if kind == 'mkv':
        return scan_mkv(path, ffprobe)
    if kind == 'bluray':
        return scan_bluray(path, ffprobe)
    return scan_dvd(path, ffprobe)
